live-shader-editor
==================

Editor for OpenGL shaders that also displays the result on-screen interactively.